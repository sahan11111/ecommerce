
<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Laravel') }}</title>

    <!-- Scripts -->
    <script src="{{ asset('js/app.js') }}" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">

    <!-- Bootstrap 4 -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

</head>
<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light bg-light shadow-sm">
            <div class="container-fluid">
                <a class="navbar-brand text-primary" href="{{ route('home') }}">
                    {{ config('app.name', 'Laravel') }} 
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="{{ __('Toggle navigation') }}">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">
                    @guest
                        <li class="nav-item">
                          <a class="nav-link"
                            href="{{ url('/') }}">{{ __('About Project') }}</a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link"
                            href="{{ route('employer.register') }}">{{ __('Company Registration') }}</a>
                        </li>
                         @if (Route::has('register'))
                          <li class="nav-item">
                            <a class="nav-link " 
                              href="{{ route('register') }}">{{ __('Job Seeker Registration') }}
                            </a>
                          </li>
                        @endif 
                      @else
                     
                      @endguest
                        
                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        @guest
                        <li class="nav-item">
                          <a class="nav-link  " href="{{ route('login') }}">{{ __('Login') }}</a>
                        </li>
                        <!-- <li class="nav-item">
                          <a class="nav-link"
                            href="{{ route('employer.register') }}">{{ __('Employer Registration') }}</a>
                        </li> -->
                         <!-- @if (Route::has('register'))
                          <li class="nav-item">
                            <a class="nav-link " 
                              href="{{ route('register') }}">{{ __('Job Seeker Registration') }}
                            </a>
                          </li>
                        @endif  -->
                      @else
                      @if(Auth::user()->user_type == 'employer')
                          <li class="nav-item">
                          <a class="nav-link" 
                                href="{{ route('home') }}">{{ __('Home') }}
                              </a>
                          </li><li class="nav-item">
                          <a class="nav-link" 
                                href="{{ route('job.create') }}">
                                {{ __('Post a Job') }}
                              </a>
                          </li>
                      
                          @else
                          <li class="nav-item">
                          <a class="nav-link" 
                                href="{{ route('home') }}">{{ __('Recent-Jobs') }}
                              </a>
                          </li>
                          <li class="nav-item">
                          <a class="nav-link" 
                                href="{{ route('alljobs') }}">{{ __('Browse All-Jobs') }}
                              </a>
                          </li>      
                          @endif
                       
                        <li class="nav-item dropdown">
                          <a id="navbarDropdown" 
                            class="nav-link dropdown-toggle" 
                            href="#" role="button" 
                            data-toggle="dropdown" aria-haspopup="true" 
                            aria-expanded="false" v-pre>
                            @if(Auth::user()->user_type == 'employer')
                              <b>Company: </b>{{ Auth::user()->company->cname }} 
                              <span class="caret"></span>
                            @else
                            <b>Job-Seeker: </b>{{ Auth::user()->name }} 
                              <span class="caret"></span>
                            @endif
                          </a>  
                          <div class="dropdown-menu dropdown-menu-right" 
                              aria-labelledby="navbarDropdown">
                            @if(Auth::user()->user_type == 'employer')
                              
                              <a class="dropdown-item" 
                                href="{{ route('company.view') }}">
                                {{ __('Profile') }}
                              </a>
                              <a class="dropdown-item" 
                                href="{{ route('applicant') }}">My Applicants
                              </a>
                            @else
                            
                              <a class="dropdown-item" 
                                href="{{ route('profile') }}">{{ __('Profile') }}
                              </a>
                              
                            @endif
                            <a class="dropdown-item" 
                              href="{{ route('logout') }}"
                              onclick="event.preventDefault();
                              document.getElementById('logout-form').submit();">
                              {{ __('Logout') }}
                            </a>

                            <form id="logout-form" 
                                  action="{{ route('logout') }}" 
                                  method="POST" style="display: none;">
                              @csrf
                            </form>
                          </div>
                        </li>
                      @endguest
                    </ul>
                </div>
            </div>
        </nav>

        <main class="py-4">
            @yield('content')
        </main>
    </div>
</body>
</html>
