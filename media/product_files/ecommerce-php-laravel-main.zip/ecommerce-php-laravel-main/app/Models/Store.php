<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Store extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'description',
        'image_path',
        'is_active',
        'is_deleted',
        'created_by',
        'updated_by'
    ];

    public function user(){
        $this->belongsTo(User::class);
    }


    public function storeCategories(){
        $this->hasMany(StoreCategory::class);
    }

}
